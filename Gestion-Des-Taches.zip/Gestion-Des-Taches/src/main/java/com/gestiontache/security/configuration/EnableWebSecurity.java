package com.gestiontache.security.configuration;

public @interface EnableWebSecurity {

}
