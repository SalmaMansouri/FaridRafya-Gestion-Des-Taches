package com.gestiontache.entities;

import javax.persistence.*;

import java.io.Serializable;
import java.util.Date;

@Entity
public class Task implements Serializable {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String description;
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
    private boolean finished;
	private Projet projet;

    public Projet getProjet() {
        return getProjet();
    }

    public void setProjet(Projet projet) {
        this.projet = projet;
    }

	public Long getId() {
		// TODO Auto-generated method stub
		return null;
	}
}
