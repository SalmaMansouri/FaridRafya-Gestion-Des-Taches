package com.gestiontache.service;

public interface UserDetailsService {

}
